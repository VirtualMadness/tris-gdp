var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "Movement", "class_movement.html", null ],
      [ "Movement2D", "class_movement2_d.html", null ]
    ] ]
];