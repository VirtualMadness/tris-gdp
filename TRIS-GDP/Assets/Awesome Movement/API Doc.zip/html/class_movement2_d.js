var class_movement2_d =
[
    [ "ShapeMode", "class_movement2_d.html#afa7cc2d2044244cbbb5adb4fbfbd4939", [
      [ "Circle", "class_movement2_d.html#afa7cc2d2044244cbbb5adb4fbfbd4939a30954d90085f6eaaf5817917fc5fecb3", null ],
      [ "Box", "class_movement2_d.html#afa7cc2d2044244cbbb5adb4fbfbd4939a3cfce651e667ab85486dd42a8185f98a", null ]
    ] ],
    [ "CanMoveTo", "class_movement2_d.html#ab2fbafd2e65105624495b5f9c9cdccee", null ],
    [ "CanMoveTo", "class_movement2_d.html#a86b0f5c52ab35e2b236014d7713f26bc", null ],
    [ "CanMoveTo", "class_movement2_d.html#a3d98a8dde83ee9ed1188908fbb04854c", null ],
    [ "CanMoveTo", "class_movement2_d.html#a036f0a52b4fa41e20baa45c298e95bed", null ],
    [ "CanMoveTo", "class_movement2_d.html#a7774e9183c2018942c621182c41c91e7", null ],
    [ "CanMoveTo", "class_movement2_d.html#a092f78badd4a20000fbacc2d7ec33155", null ],
    [ "Move", "class_movement2_d.html#aeaed0842fbc9549a6faffa9a0646d31d", null ],
    [ "Move", "class_movement2_d.html#a3b33a833f9e5e2ae96bf00adbf847aad", null ],
    [ "MoveAlongX", "class_movement2_d.html#ac6d460c86f46b5e7a54793cab7018104", null ],
    [ "MoveAlongY", "class_movement2_d.html#a3cc0948ec992640afb9d0ea70ad84aba", null ],
    [ "SetMovementPropertiesFromCollider", "class_movement2_d.html#ad788678ba520cacfe4b779cc2c17d011", null ],
    [ "SmoothGridMove", "class_movement2_d.html#a8d247b2e20c19525d97ccee2221c4aa9", null ],
    [ "SmoothGridMove", "class_movement2_d.html#a1d278fabe82912bb21b370d9dc1fa2dc", null ],
    [ "SmoothGridMoveCoroutine", "class_movement2_d.html#a0ff663af28b3d5edb3f82620033b8a19", null ],
    [ "TryMove", "class_movement2_d.html#aef25b8f5634b197b422dac14ec2d3af2", null ],
    [ "TryMove", "class_movement2_d.html#a3ef166402b6a6e7c01fb774a77949e21", null ],
    [ "layerMask", "class_movement2_d.html#a0786eae1288d8626d585e6d6203c81ae", null ],
    [ "offsetFromPivot", "class_movement2_d.html#a420dcb6b2c68a68d6e5581e844b7d9c5", null ],
    [ "radius", "class_movement2_d.html#a74be47933cdaffcb21014e2e3d71e714", null ],
    [ "shapeMode", "class_movement2_d.html#ae31607f7d0e113de5ad7ec46ebfdf6f5", null ],
    [ "size", "class_movement2_d.html#a462bc42739b4a45649d4eadf16f54fdf", null ],
    [ "isMovingUsingSmoothMove", "class_movement2_d.html#aa52bac6792860d41438b6d68cfe3263b", null ]
];