var searchData=
[
  ['ismovingusingsmoothmove',['isMovingUsingSmoothMove',['../class_movement.html#a2ffd326074b39bf2ad60d419320d64dc',1,'Movement.isMovingUsingSmoothMove()'],['../class_movement2_d.html#aa52bac6792860d41438b6d68cfe3263b',1,'Movement2D.isMovingUsingSmoothMove()']]]
];
