var searchData=
[
  ['layermask',['layerMask',['../class_movement.html#a4701024b6fceaba3c9ce93f8f7c2337d',1,'Movement.layerMask()'],['../class_movement2_d.html#a0786eae1288d8626d585e6d6203c81ae',1,'Movement2D.layerMask()']]]
];
