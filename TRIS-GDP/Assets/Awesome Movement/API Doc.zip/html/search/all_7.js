var searchData=
[
  ['radius',['radius',['../class_movement.html#a46caa49fc7e5cbf61380a2d44f681113',1,'Movement.radius()'],['../class_movement2_d.html#a74be47933cdaffcb21014e2e3d71e714',1,'Movement2D.radius()']]]
];
