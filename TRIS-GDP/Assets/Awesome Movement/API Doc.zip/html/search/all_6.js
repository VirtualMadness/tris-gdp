var searchData=
[
  ['offsetfrompivot',['offsetFromPivot',['../class_movement.html#a684997bf53e4a88dc1442248a78f2907',1,'Movement.offsetFromPivot()'],['../class_movement2_d.html#a420dcb6b2c68a68d6e5581e844b7d9c5',1,'Movement2D.offsetFromPivot()']]]
];
