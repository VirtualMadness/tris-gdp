var searchData=
[
  ['shapemode',['shapeMode',['../class_movement.html#ae45a9a2125533027a8f1755bdf7d319f',1,'Movement.shapeMode()'],['../class_movement2_d.html#ae31607f7d0e113de5ad7ec46ebfdf6f5',1,'Movement2D.shapeMode()']]],
  ['size',['size',['../class_movement2_d.html#a462bc42739b4a45649d4eadf16f54fdf',1,'Movement2D']]]
];
